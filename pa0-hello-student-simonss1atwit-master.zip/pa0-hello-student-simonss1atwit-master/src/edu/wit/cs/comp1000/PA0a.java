package edu.wit.cs.comp1000;

// TODO: document this class
public class PA0a {
	/**
	 * starts program, prints hello world
	 * @param args
	 */
	// TODO: document this function
	public static void main(String[] args) {
		//line that prints to console
		System.out.printf("Hello World");
	}

}
